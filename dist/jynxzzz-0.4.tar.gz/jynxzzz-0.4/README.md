# Jynxzzz Utils

## Overview
Welcome to `Jynxzzz Utils`! This package contains a collection of utility functions that I frequently use in my research and data analysis projects. It is designed to simplify tasks related to plotting, data analysis, and working with PyTorch.

## Installation
You can install the package directly from GitHub using pip:

pip install git+https://github.com/yourusername/jynxzzz-utils.git


or from PyPi:

pip install jynxzzz==0.1

